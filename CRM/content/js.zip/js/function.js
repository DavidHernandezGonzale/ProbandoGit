$(document).ready(function(){
$('#modificarcliente').click(function(){
    
    
    if($('#dato_gen').val()!="" && $('#estatus_cliente').val()!="" && $('#id').val()!="" && $('#nombre').val()!="" && $('#usuario').val()!="" 
    && $('#apellido').val()!="" && $('#telefono').val()!="" && 
     $('#seguimiento').val()!="" && $('#fecha_seguimiento').val()!="" 
     && $('#tarea').val()!="" && $('#fecha_tarea').val()!="" &&
    $('#estatus').val()!="" && $('#fuente_contacto').val()!="" && $('#comentario').val()!=""){
        
        $('#modificarcliente').attr('disabled','disabled');
        $.ajax({
            type:"POST",
            url:"../models/editar.php",
            data: "id=" + $('#id').val() + "&nombre=" + $('#nombre').val() + "&usuario=" + $('#usuario').val() + "&apellido=" + 
            $('#apellido').val() + "&correo=" + $('#correo').val() + "&telefono=" + $('#telefono').val() +
            "&seguimiento=" + $('#seguimiento').val() + "&fecha_seguimiento=" + $('#fecha_seguimiento').val() +
            "&tarea=" + $('#tarea').val() + "&fecha_tarea=" + $('#fecha_tarea').val() +
            "&estatus=" + $('#estatus').val() + "&fuente_contacto=" + $('#fuente_contacto').val() +
            "&estatus_cliente=" + $('#estatus_cliente').val() + "&dato_gen=" + $('#dato_gen').val() +
            "&comentario=" + $('#comentario').val(),
            success:function(r){
                $("#tempo").html(r);
            }
        });
    }
    else{
        alert("Por favor, rellene todos campos");
      
    }
});

$('#modificarProsprecto').click(function(){
    
    
    if($('#id_pro').val()!=""  && $('#usuario').val()!="" && $('#apellido').val()!="" && $('#telefono').val()!="" 
    && $('#seguimiento').val()!="" && $('#fecha_seguimiento').val()!="" 
     && $('#tarea').val()!="" && $('#fecha_tarea').val()!="" &&
    $('#estatus').val()!="" && $('#fuente_contacto').val()!="" && $('#comentario').val()!=""){
        
        $('#modificarProsprecto').attr('disabled','disabled');
        $.ajax({
            type:"POST",
            url:"../models/editar.php",
            data: "id_pro=" + $('#id_pro').val() + "&usuario=" + $('#usuario').val() + "&apellido=" + 
            $('#apellido').val() + "&correo=" + $('#correo').val() + "&telefono=" + $('#telefono').val() +
            "&seguimiento=" + $('#seguimiento').val() + "&fecha_seguimiento=" + $('#fecha_seguimiento').val() +
            "&tarea=" + $('#tarea').val() + "&fecha_tarea=" + $('#fecha_tarea').val() +
            "&estatus=" + $('#estatus').val() + "&fuente_contacto=" + $('#fuente_contacto').val() +
            "&comentario=" + $('#comentario').val(),
            success:function(r){
                $("#tempo3").html(r);
            }
        });
    }
    else{
        alert("Por favor, rellene todos campos");
      
    }
});

});

